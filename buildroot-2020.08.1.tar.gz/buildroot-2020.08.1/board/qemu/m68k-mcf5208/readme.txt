Run the emulation with:

 qemu-system-m68k -M mcf5208evb -cpu m5208 -kernel output/images/vmlinux -nographic # qemu_m68k_mcf5208_defconfig

The login prompt will appear in the terminal that started Qemu.
